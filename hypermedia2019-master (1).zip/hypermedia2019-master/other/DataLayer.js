const sqlDbFactory = require("knex");
const config = require("../config.json");
const environment = process.env.NODE_ENV || 'development';
const environmentConfig = config[environment];

let { booksDbSetup } = require("./service/DBService");
let sqlDb = sqlDbFactory({
  client: "pg",
  connection: {
    host : environmentConfig.host,
    user : environmentConfig.user,
    password : environmentConfig.password,
    database : environmentConfig.database,
    port:environmentConfig.port
  },
  debug: true
});

function setupDataLayer() {
  console.log("Setting up data layer");
  return booksDbSetup(sqlDb);
}

module.exports = { database: sqlDb, setupDataLayer };
