"use strict";

var utils = require("../utils/writer.js");
var Author = require("../service/AuthorService");
let userErrorCodes = require("../model/User").ErrorCodes

module.exports.authorsGET = function authorsGET(req, res, next) {
  var offset = req.swagger.params["offset"].value;
  var limit = req.swagger.params["limit"].value;
  var name = req.swagger.params["name"].value;

  Author.authorsGET(offset, limit, name)
  .then(function (response) {
    
    utils.writeJson(res, response, 200);
  })
  .catch(function (response) {
    if (response.code == userErrorCodes.DB_ERROR){
      utils.writeJson(res,{
                    error:response.error, 
                    details:req.details}, 
                    505)
    }
    else{
      utils.writeJson(res,response, 505);
    }
  });
};


module.exports.getAuthorById = function getAuthorById (req, res, next) {
  var authorId = req.swagger.params['authorId'].value;
  Author.getAuthorById(authorId)
    .then(function (response) {
      var author = response.authors[0] || {};
      utils.writeJson(res, author, 200);
    })
    .catch(function (response) {
      if (response.code == userErrorCodes.DB_ERROR){
        utils.writeJson(res,{
                      error:response.error, 
                      details:req.details}, 
                      505)
      }
      else{
        utils.writeJson(res,response, 505);
      }
    });
};