'use strict';

var utils = require('../utils/writer.js');
var Book = require('../service/BookService');
let userErrorCodes = require("../model/User").ErrorCodes

module.exports.booksGET = function booksGET (req, res, next) {
  var query = req.swagger.params["body"].value;
  var offset = query.offset;
  var limit = query.limit;
  var genreId = query.genreId;
  var themeId = query.themeId;
  var authorId = query.authorId;
  var authorName = query.authorName;
  var bestseller = query.bestseller;
  var favorite = query.favorite;
  var title = query.title;

  Book.booksGET(offset, limit, genreId, themeId, authorId, authorName, bestseller, favorite, title)
    .then(function (response) {
      
      utils.writeJson(res, response, 200);
    })
    .catch(function (response) {
      if (response.code == userErrorCodes.DB_ERROR){
        utils.writeJson(res,{
                      error:response.error, 
                      details:response.details}, 
                      505)
      }
      else{
        utils.writeJson(res,response, 505);
      }
    });
};

module.exports.getBookById = function getBookById (req, res, next) {
  var bookId = req.swagger.params['bookId'].value;
  Book.getBookById(bookId)
    .then(function (response) {
      var book = response.books[0] || {};
      utils.writeJson(res, book, 200);
    })
    .catch(function (response) {
      if (response.code == userErrorCodes.DB_ERROR){
        utils.writeJson(res,{
                      error:response.error, 
                      details:response.details}, 
                      505)
      }
      else{
        utils.writeJson(res,response, 505);
      }
    });
};

module.exports.getBookEvents = function getBookEvents (req, res, next) {
  var bookId = req.swagger.params['bookId'].value;
  Book.getBookEvents(bookId)
    .then(function (response) {
      var result = {
        events:response
      }
      utils.writeJson(res, result, 200);
    })
    .catch(function (response) {
      if (response.code == userErrorCodes.DB_ERROR){
        utils.writeJson(res,{
                      error:response.error, 
                      details:response.details}, 
                      505)
      }
      else{
        utils.writeJson(res,response, 505);
      }
    });
};
