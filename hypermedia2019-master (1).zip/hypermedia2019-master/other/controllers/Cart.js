"use strict";

var utils = require("../utils/writer.js");
var Cart = require("../service/CartService");
var allowed = require("../utils/misc.js").allowed;
let userErrorCodes = require("../model/User").ErrorCodes
let CartModel = require("../model/Cart").Cart
let BookReservation = require("../model/BookReservation").BookReservation


module.exports.cartGET = function cartGET(req, res, next) {
  if (allowed(req)){
    
    if(req.session.cart === undefined){
        req.session.cart = new CartModel();
    }
    
    utils.writeJson(res, req.session.cart, 200);
  }
  else {
    utils.writeJson(res,{error:"Unauthorised user"}, 403)
  }
  
  
};

module.exports.cartAdd = function cartAdd(req, res, next) {
    
    if (allowed(req)){
        if(req.session.cart === undefined){
          req.session.cart = new CartModel();
      }
        var body = req.swagger.params["body"].value;
        var books = body.books;
        for(var book of books){
            var br = new BookReservation(book.bookId, book.name, book.image,book.quantity, book.value)
            var index = req.session.cart.books.findIndex(item => item.bookId === br.bookId);
            if(index >=0){
                req.session.cart.books[index].quantity = 
                Math.max(req.session.cart.books[index].quantity + br.quantity, 0);
            }
            else{
                req.session.cart.books.push(br);
            }
            req.session.cart.total =  Math.max(req.session.cart.total + br.quantity * br.value,0);
        }
      utils.writeJson(res, req.session.cart, 200);
    }
    else {
      utils.writeJson(res,{error:"Unauthorised user"}, 403)
    }  
  };

  module.exports.cartUpdate = function cartUpdate(req, res, next) {
    if (allowed(req)){
      if(req.session.cart === undefined){
          req.session.cart = new CartModel();
      }
      var updates = req.swagger.params["body"].value.update;
     
      for (var u of updates){
        var index = req.session.cart.books.findIndex(item => item.bookId === u.bookId);
        if (index >=0){
            var br = req.session.cart.books[index];
            if (u.quantity === undefined){
                req.session.cart.total -= br.quantity * br.value;
                req.session.cart.books.splice(index, 1);
                
            }
            else{
                req.session.cart.total = Math.max(req.session.cart.total + u.quantity * br.value,0);
                req.session.cart.books[index].quantity =
                    Math.max(req.session.cart.books[index].quantity +  u.quantity,0);
            }
        }
        
      }
      utils.writeJson(res, req.session.cart, 200);
    }
    else {
      utils.writeJson(res,{error:"Unauthorised user"}, 403)
    }  
  };

module.exports.cartCommit = function cartCommit(req, res, next) {
    
    if (allowed(req)){
        
        Cart.reserveBooks(req.session.cart.books, req.session.userId)
        .then(function(response) {
        req.session.cart.books = [];
        req.session.cart.total = 0;
        utils.writeJson(res, response, 200);
    })
    .catch(function(response) {
      if (response.code == userErrorCodes.DB_ERROR){
        utils.writeJson(res,{
                      error:response.error, 
                      details:req.details}, 
                      505)
      }
      else{
        utils.writeJson(res,response, 505)
      }
        });
      }
      else {
        utils.writeJson(res,{error:"Unauthorised user"}, 403)
      }  
};

