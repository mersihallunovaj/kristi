'use strict';

var utils = require('../utils/writer.js');
var Event = require('../service/EventService');
let userErrorCodes = require("../model/User").ErrorCodes
function dateTosqlDate(date){
  return date.toISOString().slice(0, 19).replace('T', ' ');
}
module.exports.eventsGET = function eventsGET (req, res, next) {
  var offset = req.swagger.params["offset"].value;
  var limit = req.swagger.params["limit"].value;
  var startDate = req.swagger.params["startDate"].value;
  var name = req.swagger.params["name"].value;
  var endDate = req.swagger.params["endDate"].value;
  if (startDate!== undefined){
    startDate = dateTosqlDate(startDate);
  }
  if (endDate!== undefined){
    endDate = dateTosqlDate(endDate);
  }
  Event.eventsGET(offset, limit, name, startDate, endDate)
    .then(function (response) {
      
      utils.writeJson(res, response, 200);
    })
    .catch(function (response) {
      if (response.code == userErrorCodes.DB_ERROR){
        utils.writeJson(res,{
                      error:response.error, 
                      details:req.details}, 
                      505)
      }
      else{
        utils.writeJson(res,response, 505);
      }
    });
};

module.exports.getEventById = function getEventById (req, res, next) {
  var eventId = req.swagger.params['eventId'].value;
  Event.getEventById(eventId)
    .then(function (response) {
      var event = response.events[0] || {};
      utils.writeJson(res, event, 200);
    })
    .catch(function (response) {
      if (response.code == userErrorCodes.DB_ERROR){
        utils.writeJson(res,{
                      error:response.error, 
                      details:req.details}, 
                      505)
      }
      else{
        utils.writeJson(res,response, 505);
      }
    });
};
