'use strict';

var utils = require('../utils/writer.js');
var Genre = require('../service/GenreService');
var Book = require('../service/BookService');
let userErrorCodes = require("../model/User").ErrorCodes

module.exports.genresGET = function genresGET (req, res, next) {
  var offset = req.swagger.params["offset"].value;
  var limit = req.swagger.params["limit"].value;

  Genre.genresGET(offset, limit)
    .then(function (response) {
      utils.writeJson(res, response, 200);
    })
    .catch(function (response) {
      if (response.code == userErrorCodes.DB_ERROR){
        utils.writeJson(res,{
                      error:response.error, 
                      details:req.details}, 
                      505)
      }
      else{
        utils.writeJson(res,response, 505);
      }
    });
};

module.exports.getBooksByGenre = function getBooksByGenre (req, res, next) {
  var offset = req.swagger.params["offset"].value;
  var limit = req.swagger.params["limit"].value;  
  var genreId = req.swagger.params['genreId'].value;
  Book.booksGET(offset, limit, [genreId])
    .then(function (response) {
      utils.writeJson(res, response, 200);
    })
    .catch(function (response) {
      if (response.code == userErrorCodes.DB_ERROR){
        utils.writeJson(res,{
                      error:response.error, 
                      details:req.details}, 
                      505)
      }
      else{
        utils.writeJson(res,response, 505);
      }
    });
};
