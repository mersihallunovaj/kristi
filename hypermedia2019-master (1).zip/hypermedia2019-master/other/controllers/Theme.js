'use strict';

var utils = require('../utils/writer.js');
var Theme = require('../service/ThemeService');
var Book = require('../service/BookService');
let userErrorCodes = require("../model/User").ErrorCodes

module.exports.themesGET = function themesGET (req, res, next) {
  var offset = req.swagger.params["offset"].value;
  var limit = req.swagger.params["limit"].value;

  Theme.themesGET(offset, limit)
    .then(function (response) {
      utils.writeJson(res, response, 200);
    })
    .catch(function (response) {
      if (response.code == userErrorCodes.DB_ERROR){
        utils.writeJson(res,{
                      error:response.error, 
                      details:req.details}, 
                      505)
      }
      else{
        utils.writeJson(res,response, 505);
      }
    });
};

module.exports.getBooksByTheme = function getBooksByTheme (req, res, next) {
  var offset = req.swagger.params["offset"].value;
  var limit = req.swagger.params["limit"].value;  
  var themeId = req.swagger.params['themeId'].value;
  Book.booksGET(offset, limit, undefined, [themeId])
    .then(function (response) {
      utils.writeJson(res, response, 200);
    })
    .catch(function (response) {
      if (response.code == userErrorCodes.DB_ERROR){
        utils.writeJson(res,{
                      error:response.error, 
                      details:req.details}, 
                      505)
      }
      else{
        utils.writeJson(res,response, 505);
      }
    });
};

