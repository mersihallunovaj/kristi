"use strict";

var utils = require("../utils/writer.js");
var User = require("../service/UserService");
let userErrorCodes = require("../model/User").ErrorCodes
let UserModel = require("../model/User").User
let CartModel = require("../model/Cart").Cart

module.exports.userLoginPOST = function userLoginPOST(req, res, next) {
  var body = req.swagger.params["body"].value;
  var username = body.username;
  var password = body.password;
  
  User.userLoginPOST(username, password)
    .then(function(response) {
      var u = new UserModel(response.userId, response.name, username, response.address)
      req.session.userId = response.userId;
      if (req.session.cart === undefined){
        req.session.cart = new CartModel();
      }
      utils.writeJson(res, u, 200);
    })
    .catch(function(response) {
      req.session.userId = null;
      if (response.code == userErrorCodes.USER_UNAUTHORIZED){
        utils.writeJson(res,{error:response.error}, 403)
      }
      else if (response.code == userErrorCodes.DB_ERROR){
        utils.writeJson(res,{
                      error:response.error, 
                      details:req.details}, 
                      505)
      }
      else{
        utils.writeJson(res,response, 505);
      }
    });
};

module.exports.userLogoutPOST = function userLogoutPOST(req, res, next) {
  req.session.userId = null
  req.session = null;
  utils.writeJson(res,{ message:"Succesfully Logged out"}, 200);
};



module.exports.userRegisterPOST = function userRegisterPOST(req, res, next) {
  var body = req.swagger.params["body"].value;

  User.userRegisterPOST(body)
    .then(function(response) {
      var u = new UserModel(response.userId, body.name, body.email, body.address)
      req.session.userId = response.userId;
      req.session.cart = new CartModel();
      utils.writeJson(res, u, 200);
    })
    .catch(function(response) {
      if (response.code == userErrorCodes.USER_UNAUTHORIZED){
        utils.writeJson(res,{error:response.error}, 403)
      }
      else if (response.code == userErrorCodes.DB_ERROR){
        utils.writeJson(res,{
                      error:response.error, 
                      details:req.details}, 
                      505)
      }
      else{
        utils.writeJson(res,response, 505)
      }
    });
};