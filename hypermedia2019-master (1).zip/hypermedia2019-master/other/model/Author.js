class Author {
    constructor(id, name, image, bio, birthdate) {
        this.authorId = id
        this.name = name;
        this.image = image;
        this.bio = bio;
        this.birthdate = birthdate;
    }
 
 }


module.exports = {  
    Author: Author
}

