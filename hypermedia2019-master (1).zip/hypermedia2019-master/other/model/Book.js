class Book {
    constructor(id, title, image, price, abstract, status, 
                authors, similarBooks, facts, genres,themes, reviews, bestseller, favorite) {
        this.bookId = id
        this.title = title;
        this.image = image;
        this.price = price
        this.abstract = abstract
        this.authors = authors;
        this.similarBooks = similarBooks;
        this.facts = facts;
        this.reviews = reviews;
        this.genres = genres;
        this.themes = themes;
        this.status = status;
        this.bestseller = bestseller;
        this.favorite = favorite;
    }
 
 }


module.exports = {  
    Book: Book
}

