class BookReservation {
    constructor(id, name, image, quantity, value) {
        this.bookId = id
        this.name = name;
        this.image = image;
        this.quantity = quantity;
        this.value = value;
    }
 
 }


module.exports = {  
    BookReservation: BookReservation
}

