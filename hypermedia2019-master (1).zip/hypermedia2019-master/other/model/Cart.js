
class Cart {
    constructor() {
        this.total = 0;
        this.books = [];
        
    }
 }

module.exports = {  
    Cart: Cart
}

