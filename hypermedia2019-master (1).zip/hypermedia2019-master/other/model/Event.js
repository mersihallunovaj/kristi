class Event {
    constructor(id, name, image, location, date, books, guests, description) {
        this.eventId = id
        this.name = name;
        this.image = image;
        this.location = location;
        this.date = date;
        this.description = description;
        this.books = books;
        this.guests = guests;
    }
 
 }


module.exports = {  
    Event: Event
}

