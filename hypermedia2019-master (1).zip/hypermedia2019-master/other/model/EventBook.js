class EventBook {
    constructor(id, title, image) {
        this.bookId = id
        this.title = title;
        this.image = image;
    }
 
 }


module.exports = {  
    EventBook: EventBook
}

