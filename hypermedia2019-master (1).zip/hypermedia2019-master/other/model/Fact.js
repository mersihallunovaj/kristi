class Fact {
    constructor(id, description) {
        this.factId = id;
        this.description = description;
    }
 }

module.exports = {  
    Fact: Fact
}

