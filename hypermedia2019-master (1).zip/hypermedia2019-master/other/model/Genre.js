class Genre {
    constructor(id, name) {
        this.genreId = id;
        this.name = name;
    }
 }

module.exports = {  
    Genre: Genre
}

