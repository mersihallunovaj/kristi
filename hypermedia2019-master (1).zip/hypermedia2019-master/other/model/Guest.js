class Guest {
    constructor(id, name, bio, image) {
        this.guestId = id
        this.name = name;
        this.image = image;
        this.bio = bio;
    }
 
 }


module.exports = {  
    Guest: Guest
}

