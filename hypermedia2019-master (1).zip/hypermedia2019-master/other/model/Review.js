class Review {
    constructor(id, description, author, timestamp) {
        this.reviewId = id;
        this.description = description;
        this.author = author;
        this.timestamp = timestamp;
    }
 }

module.exports = {  
    Review: Review
}

