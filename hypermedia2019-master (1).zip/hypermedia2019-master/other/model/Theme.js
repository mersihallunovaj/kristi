class Theme {
    constructor(id, name) {
        this.themeId = id;
        this.name = name;
    }
 }

module.exports = {  
    Theme: Theme
}

