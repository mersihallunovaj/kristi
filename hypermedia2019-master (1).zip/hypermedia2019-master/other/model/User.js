class User {
    constructor(userId, name, email, address) {
        this.userId = userId;
        this.email = email;
        this.name = name;
        this.address = address;
    }
 
 }

var errorCodes = {
    "USERNAME_UNAVAILABLE":1,
    "USER_UNAUTHORIZED":2,
    "DB_ERROR":3
}

module.exports = {  
    User: User,
    ErrorCodes:errorCodes
}

