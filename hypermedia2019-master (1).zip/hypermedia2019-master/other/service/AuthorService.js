"use strict";

let sqlDb = require('./DBService').db;
let userErrorCodes = require("../model/User").ErrorCodes
let Author = require("../model/Author").Author
let selectFields = ['authorId', 'name', 'bio', 'imageURL as image'];

function authorsGET (offset, limit, name, authorId) {
  limit = limit || 200;
  if(limit ===0)
    limit = 1;
  offset = offset || 0;
  offset = offset * limit;
  if (offset < 0)
    offset = 0;
  sqlDb = require('./DBService').db
  
  return new Promise(function(resolve, reject) {
    var query = sqlDb.select(selectFields)
    .select(sqlDb.raw('DATE(\"birthDate\") as \"birthDate\"'))
    .select(sqlDb.raw('count(*) OVER() as full_count')).from("author");
    if (name !== undefined && name !=="" && name !== null){
      query = query.whereRaw("LOWER(name) like LOWER('%" + name + "%')");
    }
    if (authorId !== undefined){
        query = query.where('authorId', authorId);
      }
    query.limit(limit).offset(offset)
    .then(function(response){
      
      var count = 0;
      var authors;
      if (response !== undefined && response.length>0)
        authors = response.map(item =>
        new Author(item.authorId, item.name, item.image, item.bio, new Date(item.birthDate)));
        count = response[0]['full_count'];
      var res = {
        authors:authors,
        pages: Math.ceil(count/ limit),
        current_page : Math.floor(offset / limit) + 1
      }
        resolve(res);
    })
    .catch(function(response) {
      reject({
          code: userErrorCodes.DB_ERROR,
          error: "Database Error",
          details: response
        })
      });

  });
  };
  

  exports.authorsGET = authorsGET;

  exports.getAuthorById = function(authorId) {
    return authorsGET(0, 200, undefined,  authorId);
  };
  