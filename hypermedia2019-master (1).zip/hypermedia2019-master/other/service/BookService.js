"use strict";

let sqlDb = require('./DBService').db;
let userErrorCodes = require("../model/User").ErrorCodes
let Author = require("../model/Author").Author
let Fact = require("../model/Fact").Fact
let Review = require("../model/Review").Review
let SimilarBook = require("../model/SimilarBook").SimilarBook
let Book = require("../model/Book").Book
let Genre = require("../model/Genre").Genre
let Theme = require("../model/Theme").Theme
let ORM = require("../utils/misc.js").ORM

let selectFields = ['book.bookId', 'book.abstract', 'book.title', 'book.price', 'book.imageURL',
                      'review.description as reviewDescription', 'review.timestamp as reviewTimestamp',
                       'review.author as reviewAuthor', 'book.status', "book.bestseller", "book.favorite",
                      'fact.description as factDescription', 'genre.genreId', 'genre.name as genreName',
                      'theme.themeId', 'theme.name as themeName', 'author.authorId',
                      'author.bio as authorBio', 'author.name as authorName',
                      'author.birthDate as authorBirthdate', 'author.imageURL as authorImage',
                      'similarBook.secondBookId as similarBookId', 'book2.title as similarBookTitle', 
                      'book2.imageURL as similarBookImage'];
let keyField = 'bookId';
let classConstr = Book;
let singleFields = [{
                      key:"status",
                      DBKey:"status",
                      subfields:[],
                    },
                    {
                      key:"abstract",
                      DBKey:"abstract",
                      subfields:[]
                    },
                    {
                      key:"bestseller",
                      DBKey:"bestseller",
                      subfields:[]
                    },
                    {
                      key:"favorite",
                      DBKey:"favorite",
                      subfields:[]
                    },
                    {
                      key:"image",
                      DBKey:"imageURL",
                      subfields:[]
                    },
                    {
                    key:"title",
                    DBKey:"title",
                    subfields:[]
                    },
                    {
                      key:"price",
                      DBKey:"price",
                      subfields:[]
                      }];
let arrayFields = [
                  {
                    key:"authors",
                    subfields:[{
                                key:"authorId",
                                DBKey:"authorId"
                              },
                              {
                                key:"name",
                                DBKey:"authorName"
                              },
                              {
                                key:"image",
                                DBKey:"authorImage"
                              },
                              {
                                key:"bio",
                                DBKey:"authorBio"
                              },
                              {
                                key:"birthdate",
                                DBKey:"authorBirthdate"
                              }],
                    classConstr:Author
                  },
                  {
                    key:"themes",
                    subfields:[{
                                key:"themeId",
                                DBKey:"themeId"
                              },
                              {
                                key:"name",
                                DBKey:"themeName"
                              }],
                    classConstr:Theme
                  },
                  {
                    key:"genres",
                    subfields:[{
                                key:"genreId",
                                DBKey:"genreId"
                              },
                              {
                                key:"name",
                                DBKey:"genreName"
                              }],
                    classConstr:Genre
                  },
                  {
                    key:"reviews",
                    subfields:[{
                                key:"reviewId",
                                DBKey:"reviewId"
                              },
                              {
                                key:"description",
                                DBKey:"reviewDescription"
                              },
                              {
                                key:"author",
                                DBKey:"reviewAuthor"
                              },
                              {
                                key:"timestamp",
                                DBKey:"reviewTimestamp"
                              }],
                    classConstr:Review
                  },
                  {
                    key:"facts",
                    subfields:[{
                                key:"factId",
                                DBKey:"factId"
                              },
                              {
                                key:"description",
                                DBKey:"factDescription"
                              }],
                    classConstr:Fact
                  },
                  {
                    key:"similarBooks",
                    subfields:[{
                                key:"bookId",
                                DBKey:"similarBookId"
                              },
                              {
                                key:"title",
                                DBKey:"similarBookTitle"
                              },
                              {
                                key:"image",
                                DBKey:"similarBookImage"
                              }],
                    classConstr:SimilarBook
                  }
                    ]
/**
 * Books available in the inventory
 * List of books available in the inventory
 *
 * offset Integer Pagination offset. Default is 0. (optional)
 * limit Integer Maximum number of items per page. Default is 20 and cannot exceed 500. (optional)
 * genreId list of genres to filter
 * themeId list of themes to filter by
 * authorId list of authors to filter by
 * returns List
 **/

function booksGET (offset, limit, genreId, themeId, authorId, authorName, bestseller, favorite, title, bookId) {
    limit = limit || 200;
    if(limit ===0)
      limit = 1;
    offset = offset || 0;
    offset = offset * limit;
    if (offset < 0)
      offset = 0;
    sqlDb = require('./DBService').db
    
    return new Promise(function(resolve, reject) {
      var query = sqlDb.select(selectFields)
      .select(sqlDb.raw('count(*) OVER() as full_count')).from("book")
      .leftJoin('bookGenre', "book.bookId", "bookGenre.bookId")
      .leftJoin("fact", "book.bookId", "fact.bookId")
      .leftJoin("similarBook", "book.bookId", "similarBook.firstBookId")
      .leftJoin("book as book2", "similarBook.secondBookId", "book2.bookId")
      .leftJoin("review", "book.bookId", "review.bookId")
      .leftJoin('genre', "bookGenre.genreId", "genre.genreId")
      .leftJoin('bookTheme', "book.bookId", "bookTheme.bookId")
      .leftJoin('theme', "theme.themeId", "bookTheme.themeId")
      .leftJoin('bookAuthor', "book.bookId", "bookAuthor.bookId")
      .leftJoin('author', "author.authorId", "bookAuthor.authorId");
      if (genreId !== undefined && genreId.length > 0){
        query = query.whereIn("genre.genreId", genreId);
      }
      if (themeId !== undefined && themeId.length > 0){
        query = query.whereIn("theme.themeId", themeId);
      }
      if (authorId !== undefined && authorId.length > 0){
        query = query.whereIn("author.authorId", authorId);
      }
      if (authorName !== undefined && authorName != ""  && authorName != null){
        query = query.whereRaw("LOWER(author.name) like LOWER('%" + authorName + "%')");
      }
      if (title !== undefined && title != ""  && title != null){
        query = query.whereRaw("LOWER(book.title) like LOWER('%" + title + "%')");
      }
      if (bookId !== undefined){
        query = query.where({"book.bookId": bookId});
      }
      if (bestseller !== undefined && bestseller === true){
        query = query.where({"book.bestseller": true});
      }
      if (favorite !== undefined && favorite === true){
        query = query.where({"book.favorite": true});
      }
      
      query.then(function(response){
          var books = ORM(response, Book, keyField, singleFields, arrayFields);
          var count = 0;
          if (books !== undefined && books.length>0)
            count = response[0]['full_count'];
          var res = {
            books:books.slice(offset, offset+limit),
            pages: Math.ceil(count/ limit),
            current_page : Math.floor(offset / limit) + 1
          }

          resolve(res);
      })
      .catch(function(response) {
        reject({
            code: userErrorCodes.DB_ERROR,
            error: "Database Error",
            details: response
          })
        });

    });
  };
  
  exports.booksGET = booksGET;
  /**
   * Find book by ID
   * Returns a book
   *
   * bookId Long ID of book to return
   * returns Book
   **/
  exports.getBookById = function(bookId) {
    
    return booksGET(0, 200, [], [], [], undefined, undefined, undefined, undefined, bookId);
  };

  exports.getBookEvents = function(bookId) {
    
    return new Promise(function(resolve, reject) {
      var query = sqlDb.select(["event.eventId", "event.name"])
      .from("event")
      .join('bookEvent', "event.eventId", "bookEvent.eventId")
      .join("book", "book.bookId", "bookEvent.bookId")
      .where("book.bookId",bookId)
      
      query.then(function(response){
          response = response || [];
          resolve(response);
      })
      .catch(function(response) {
        reject({
            code: userErrorCodes.DB_ERROR,
            error: "Database Error",
            details: response
          })
        });

    });
  };
  
  