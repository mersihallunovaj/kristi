'use strict';
let sqlDb;
let userErrorCodes = require("../model/User").ErrorCodes

/**
 * 
 * Save Book Reservations in Db
 *
 * books [BookResevation] 
 * userId integer
 * no response value expected for this operation
 **/
exports.reserveBooks = function(books, userId) {
  sqlDb = require('./DBService').db
  return new Promise(function(resolve, reject) {
    sqlDb.raw(
        "INSERT INTO \"reservation\" (\"userId\") VALUES (?) RETURNING \"reservationId\"",
        [userId]
      )
      .then((data) => {
        var reservationId = data.rows[0].reservationId;
        var fieldsToInsert = books.map(book => 
        ({ reservationId: reservationId, bookId:book.bookId, quantity: book.quantity })); 
        sqlDb('bookReservation').insert(fieldsToInsert)
        .then(() => { 
            resolve({
                message:"Added Succesfully"
            })
         })
        .catch(function(response) { 
            reject({
                code: userErrorCodes.DB_ERROR,
                error: response.stack,
                details: response
          })
        }); 
      })
    .catch(function(response) {
      console.log(response.stack)
      reject({
          code: userErrorCodes.DB_ERROR,
          error: response.stack,
          details: response
        })
      });
    
    });
}

