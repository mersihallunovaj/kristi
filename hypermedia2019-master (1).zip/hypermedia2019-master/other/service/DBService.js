"use strict";

let sqlDb;

exports.booksDbSetup = function(database) {
  sqlDb = database;
  exports.db = sqlDb;
  
  return database.schema.hasTable("book").then(exists => {
    if (!exists) {
        return createBookTable()
        .then(createGenreTable)
        .then(createThemeTable)
        .then(createBookGenreTable)
        .then(createBookThemeTable)
        .then(createAuthorTable)
        .then(createEventTable)
        .then(createGuestTable)
        .then(createReviewTable)
        .then(createFactTable)
        .then(createBookAuthorTable)
        .then(createSimilarTable)
        .then(createUserTable)
        .then(createReservationTable)
        .then(createBookReservationTable)
        .then(createBookEventTable);
    }
    
  });
};

function createBookTable(){
  return sqlDb.schema.createTable("book", table => {
    table.increments("bookId");
    table.text("title");
    table.text("abstract");
    table.text("imageURL");
    table.boolean("bestseller");
    table.boolean("favorite");
    table.float("price");
    table.enum("status", ["available", "out of stock"]);
  });
}

function createUserTable(){
  return sqlDb.schema.createTable("user", table => {
    table.increments("userId");
    table.text("email").unique();
    table.text("name");
    table.text("password");
    table.text("address");
  });
}

function createReservationTable(){
  return sqlDb.schema.createTable("reservation", table => {
    table.increments("reservationId");
    table.integer("userId");
    table.timestamp("timestamp");
    table.foreign("userId").references("userId").inTable("user");
  });
}

function createBookReservationTable(){
  return sqlDb.schema.createTable("bookReservation", table => {
    table.increments("bookReservationId");
    table.integer("bookId");
    table.integer("reservationId");
    table.integer("quantity");
    table.foreign("bookId").references("bookId").inTable("book");
    table.foreign("reservationId").references("reservationId").inTable("reservation");
  });
}

function createGenreTable(){
  return sqlDb.schema.createTable("genre", table => {
    table.increments("genreId");
    table.text("name").unique();
  });
}

function createBookGenreTable(){
  return sqlDb.schema.createTable("bookGenre", table => {
    table.increments("bookGenreId");
    table.integer("bookId");
    table.integer("genreId");
    table.foreign("bookId").references("bookId").inTable("book");
    table.foreign("genreId").references("genreId").inTable("genre");
    table.unique(['bookId', 'genreId']);
  });
}

function createThemeTable(){
  return sqlDb.schema.createTable("theme", table => {
    table.increments("themeId");
    table.text("name").unique();
  });
}

function createBookThemeTable(){
  return sqlDb.schema.createTable("bookTheme", table => {
    table.increments("bookThemeId");
    table.integer("bookId");
    table.integer("themeId");
    table.foreign("bookId").references("bookId").inTable("book");
    table.foreign("themeId").references("themeId").inTable("theme");
    table.unique(['bookId', 'themeId']);
  });
}

function createBookEventTable(){
  return sqlDb.schema.createTable("bookEvent", table => {
    table.increments("bookEventId");
    table.integer("bookId");
    table.integer("eventId");
    table.foreign("bookId").references("bookId").inTable("book");
    table.foreign("eventId").references("eventId").inTable("event");
    table.unique(['bookId', 'eventId']);
  });
}

function createAuthorTable(){
  return sqlDb.schema.createTable("author", table => {
    table.increments("authorId");
    table.text("name");
    table.text("bio");
    table.text("imageURL");
    table.date("birthDate");
    });
}

function createEventTable(){
  return sqlDb.schema.createTable("event", table => {
    table.increments("eventId");
    table.text("name");
    table.text("location");
    table.text("imageURL");
    table.date("date");
    });
}

function createGuestTable(){
  return sqlDb.schema.createTable("guest", table => {
    table.increments("guestId");
    table.text("name");
    table.text("bio");
    table.text("imageURL");
    table.integer("eventId");
    table.foreign("eventId").references("eventId").inTable("event");
    });
}

function createReviewTable(){
  return sqlDb.schema.createTable("review", table => {
    table.increments("reviewId");
    table.text("description");
    table.text("author");
    table.timestamp("timestamp");
    table.integer("bookId");
    table.foreign("bookId").references("bookId").inTable("book");
    });
}

function createFactTable(){
  return sqlDb.schema.createTable("fact", table => {
    table.increments("factId");
    table.text("description");
    table.integer("bookId");
    table.foreign("bookId").references("book.bookId")
    });
}

function createBookAuthorTable(){
  return sqlDb.schema.createTable("bookAuthor", table => {
    table.increments("bookAuthorId");
    table.integer("bookId");
    table.integer("authorId");
    table.foreign("bookId").references("book.bookId");
    table.foreign("authorId").references("author.authorId");
    table.unique(['bookId', 'authorId']);
  });
}

function createSimilarTable(){
  return sqlDb.schema.createTable("similarBook", table => {
    table.increments("bookSimilarityId");
    table.integer("firstBookId");
    table.integer("secondBookId");
    table.foreign("firstBookId").references("book.bookId");
    table.foreign("secondBookId").references("book.bookId");
    table.unique(['firstBookId', 'secondBookId']);
  });  
}

exports.db = sqlDb
