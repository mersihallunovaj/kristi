"use strict";

let sqlDb = require('./DBService').db;
let userErrorCodes = require("../model/User").ErrorCodes
let Event = require("../model/Event").Event
let EventBook = require("../model/EventBook").EventBook
let Guest = require("../model/Guest").Guest
let ORM = require("../utils/misc.js").ORM

let selectFields = ['event.eventId', 'event.name', 'event.imageURL as image',
                    'book.title', 'book.imageURL as bookImage', 'book.bookId',
                    'event.location','event.description',
                    'guest.guestId', 'event.date as eventDate',
                    'guest.name as guestName', 'guest.bio as guestBio', 'guest.imageURL as guestImage'
                     ];
let keyField = 'eventId';
let classConstr = Event;
let singleFields = [{
                      key:"name",
                      DBKey:"name",
                      subfields:[],
                    },
                    {
                        key:"location",
                        DBKey:"location",
                        subfields:[],
                    },
                    {
                        key:"date",
                        DBKey:"eventDate",
                        subfields:[],
                    },
                    {
                      key:"description",
                      DBKey:"description",
                      subfields:[],
                  },
                    {
                      key:"image",
                      DBKey:"image",
                      subfields:[]
                    }
                    ];
let arrayFields = [
                  {
                    key:"books",
                    subfields:[{
                                key:"bookId",
                                DBKey:"bookId"
                              },
                              {
                                key:"title",
                                DBKey:"title"
                              },
                              {
                                key:"image",
                                DBKey:"bookImage"
                              }],
                    classConstr:EventBook
                  },
                  {
                    key:"guests",
                    subfields:[{
                                key:"guestId",
                                DBKey:"guestId"
                              },
                              {
                                key:"name",
                                DBKey:"guestName"
                              },
                              {
                                key:"image",
                                DBKey:"guestImage"
                              },
                              {
                                key:"bio",
                                DBKey:"guestBio"
                              }],
                    classConstr:Guest
                  }
                  ]

function eventsGET (offset, limit, name, startDate, endDate, eventId) {
    limit = limit || 200;
    if(limit ===0)
      limit = 1;
    offset = offset || 0;
    offset = offset * limit;
    if (offset < 0)
      offset = 0;
    sqlDb = require('./DBService').db
    
    return new Promise(function(resolve, reject) {
        var query = sqlDb.select(selectFields)
        .select(sqlDb.raw('count(*) OVER() as full_count')).from("event")
        .leftJoin('bookEvent', "event.eventId", "bookEvent.eventId")
        .leftJoin('book', "bookEvent.bookId", "book.bookId")
        .leftJoin('guest', "event.eventId", "guest.eventId");
        if (startDate !== undefined && startDate != ""){
        query = query.where("event.date", '>=', startDate);
        }
        if (endDate !== undefined && endDate != ""){
            query = query.where("event.date", '<=', endDate);
        }
        if (name !== undefined && name != "" && name !=null){
        query = query.whereRaw("LOWER(event.name) like LOWER('%" + name + "%')");
        }
        if (eventId !== undefined){
        query = query.where({"event.eventId": eventId});
        }
        
        query.then(function(response){
            var events = ORM(response, Event, keyField, singleFields, arrayFields);
            var count = 0;
            if (events !== undefined && events.length>0)
              count = response[0]['full_count'];
            var res = {
              events:events.slice(offset, offset+limit),
              pages: Math.ceil(count/ limit),
              current_page : Math.floor(offset / limit) + 1
            }
            resolve(res);
        })
        .catch(function(response) {
        reject({
            code: userErrorCodes.DB_ERROR,
            error: "Database Error",
            details: response
            })
        });

    });
  };
  
  exports.eventsGET = eventsGET;
  /**
   * Find book by ID
   * Returns a book
   *
   * bookId Long ID of book to return
   * returns Book
   **/
  exports.getEventById = function(eventId) {
    return eventsGET(0, 200, undefined, undefined, undefined, eventId);
  };
  
  