"use strict";

let sqlDb = require('./DBService').db;
let userErrorCodes = require("../model/User").ErrorCodes

function themesGET (offset, limit) {
  limit = limit || 200;
  offset = offset || 0;
  sqlDb = require('./DBService').db
  
  return new Promise(function(resolve, reject) {
    var query = sqlDb.select(["themeId", "name"]).from("theme");
    
    query.limit(limit).offset(offset)
    .then(function(response){
        resolve(response);
    })
    .catch(function(response) {
      reject({
          code: userErrorCodes.DB_ERROR,
          error: "Database Error",
          details: response
        })
      });

  });
  };
  
  exports.themesGET = themesGET;
  