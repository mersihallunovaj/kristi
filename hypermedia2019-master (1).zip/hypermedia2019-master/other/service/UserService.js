'use strict';
let sqlDb;
let hash = require("../utils/misc.js").hashPassword
let compareHash = require("../utils/misc.js").compareHash
let userErrorCodes = require("../model/User").ErrorCodes

/**
 * Login
 * Login with a form
 *
 * username String 
 * password String 
 * no response value expected for this operation
 **/
exports.userLoginPOST = function(username,password) {
  sqlDb = require('./DBService').db
  return new Promise(function(resolve, reject) {
    sqlDb("user").where({
      email: username,
    }).select('*')
    .then(data =>{
      if (data.length ==0){
        reject({
          code: userErrorCodes.USER_UNAUTHORIZED,
          error:"Authentication Failed"
        });
      }
      else{
        var user = data[0];
        if (compareHash(password, user.password)){
          resolve(user);
        }
        else{
          reject({
            code: userErrorCodes.USER_UNAUTHORIZED,
            error:"Authentication Failed"
          });
        }
      }
    })
    .catch(function(response) {
      reject({
          code: userErrorCodes.DB_ERROR,
          error: "Database Error",
          details: response
        })
      });
  });
}


/**
 * Register
 * Register into the store
 *
 * body User 
 * no response value expected for this operation
 **/
exports.userRegisterPOST = function(body) {
  sqlDb = require('./DBService').db
  var name = body.name
  var email = body.email
  var password = body.password
  var address = body.address
  return new Promise(function(resolve, reject) {
    sqlDb("user").where({
      email: email,
    }).select('userId')
    .then(data => {
      if (data === undefined || data.length == 0) {
        //register the user
        hash(password).then((hashedPass) =>{
          sqlDb.raw(
            "INSERT INTO \"user\" (email, password, name, address) VALUES (?, ?, ?, ?) RETURNING \"userId\"",
            [email, hashedPass, name, address]
          )
          .then((data) => {
            resolve(data.rows[0])
          })
        })
        .catch(function(response) {
          console.log(response)
          reject({
              code: userErrorCodes.DB_ERROR,
              error: "Database Error",
              details: response
            })
          });
      }
      else{
        reject({
          code: userErrorCodes.USER_UNAUTHORIZED,
          error:"User already exists"
        })
      }
    }).catch(function(response) {
      reject({
          code: userErrorCodes.DB_ERROR,
          error: "Database Error",
          details: response
        })
      });
  
  });
  
}