let bcrypt = require("bcrypt")

module.exports.hashPassword = function (password)  {
    return new Promise((resolve, reject) =>
      bcrypt.hash(password, 10, (err, hash) => {
        err ? reject(err) : resolve(hash)
      })
    )
  }

module.exports.compareHash = function(password, hash) {
  if(bcrypt.compareSync(password, hash)) {
    return true;
   } else {
    return false;
   }
  

}

module.exports.allowed = function(req) {
  
  if(req.session.userId){
    return true;
  }
  else{
    return false;
  }
}

module.exports.ORM = function (response, classConstr, keyField, singleFields, arrayFields){
  var map = {};
  var count;
  response.forEach(function (e) {
    var k = e[keyField];
    if (map[k] === undefined){
      var element = new classConstr(k);
      for(var field of singleFields){
        if (e[field.DBKey] != null)
          element[field.key] = e[field.DBKey];
      }
      for(var field of arrayFields){
        element[field.key] = [];
      }
      map[k] = element;
    }
    for(var field of arrayFields){
      var arrayEl = new field.classConstr()
      var added_Fields = false;
      count=0;
      for(var subField of field.subfields){
        
        if(e[subField.DBKey]!= null){
          //don't repeat fields 
          if (count==0){
            if (containsObjectwithKeyValue(map[k][field.key],subField.key,e[subField.DBKey]))
              break;
          }
          added_Fields = true;
            arrayEl[subField.key] = e[subField.DBKey];
        }
      } 
      if (added_Fields){
        map[k][field.key].push(arrayEl);
      }
      
    }
    });
  return Object.keys(map).map(function (k) {
    return map[k];
  });
}

function containsObjectwithKeyValue(array,key,value){
  var index = array.findIndex(item => item[key] == value);
  if(index>=0)
    return true;
  else
    return false;
}