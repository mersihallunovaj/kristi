var similarBookHTML = "<a class='product-box' href={0}> \
                        <span class='img'>\
                      <span style='background-image: url(\"{1}\")' class='i first bounding-box'></span> \
                     </span> \
                    <span class='text'>\
                <strong class='similarTitle'>{2}</strong>\
                </div>\
                </span>\
                </a>";
var rowHTML = "<a  class='list-group-item clearfix'>\
                    <span ><i class='{0}'></i></span>\
                    {1}\
                  </a>";
var authorId, author;
var image=$("#big-image");
var authorsList=$("#authorsList");
var similarBooks=$("#collection-list");
var abstract = $("#abstract");
var title=$("#title");
var bookList;
var authorBooksList= $("#authorBooksList");



function showResults(author, books){
    console.log(author);
    title.html(author.name);
    image.css('background-image', 'url(' + author.image + ')');
    abstract.html(author.bio);
    authorsList.html(author.birthdate.substring(0,10));
    var src, el;
    for (var b of books.slice(0, 4)){
        src = similarBookHTML.format(BOOK_PAGE+'?bookId='+b.bookId, b.image, b.title); 
        el = $(src);
        similarBooks.append(el);
    }
    authorBooksList.html(authorBooksList.html() + "<a href='"+BOOKS_PAGE+"?authorId="+
                    authorId +"&authorName=" +encodeURI(author.name) +"'> Sea all!</a>");
}


function init(){
    authorId = GetQueryParams("authorId",window.location.href);
    if(authorId === null){
        showError("No Author specified");
        Redirect('/');
        return;
    }
    clearMessages();
    getAuthorById(authorId)
    .done(function (result,a,request) {
         console.log(result);
        if(result.authorId === undefined){
            showError("Author does not exist");
            Redirect(AUTHORS_PAGE);
        }
        author = result;
        var query = { 
                offset:0,
                limit:4,
                authorId:[parseInt(authorId)]};
        console.log(query);
        getBooks(query)
        .done(function (result,a,request) {
        bookList = result.books;
        console.log(bookList);
        showResults(author,result.books);
        
    }).fail(function (err){
        showError("Error getting author books",err);
    });
        
    }).fail(function (err){
        showError("Error getting author details",err);
    });
}