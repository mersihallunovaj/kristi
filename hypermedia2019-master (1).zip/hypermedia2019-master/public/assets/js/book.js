var similarBookHTML = "<a class='product-box' href={0}> \
                        <span class='img'>\
                      <span style='background-image: url(\"{1}\")' class='i first bounding-box'></span> \
                     </span> \
                    <span class='text'>\
                <strong class='similarTitle'>{2}</strong>\
                </div>\
                </span>\
                </a>";
var rowHTML = "<a  class='list-group-item clearfix'>\
                    <span ><i class='{0}'></i></span>\
                    {1}\
                  </a>";

var euro = '\u20AC ';
var bookId, book;
var image=$("#big-image");
var authorsList=$("#authorsList");
var genresList=$("#genresList");
var themesList=$("#themesList");
var reviewsList=$("#reviewsList");
var factsList=$("#factsList");
var eventsList=$("#eventsList");
var quantity=$("#quantity");
var similarBooks=$("#collection-list");
var abstract = $("#abstract");
var statusView = $("#statusView");
var title=$("#title");
var price=$("#price-preview");


function addBookToCart(){
    clearMessages();
    if (!checkLogin()){
        showError("Need to be registered to order books! <a href='"+LOGIN_PAGE+"?bookId="+bookId
                    +"'>Login In!</a>");
        return;
    }
    console.log("Booking");
    var books =[
            {
                bookId:parseInt(bookId), 
                quantity:parseInt(quantity.val()),
                value:book.price,
                image:book.image,
                name:book.title
            }
        ];
        addToCartPost(books)
        .done(function (result,a,request) {
            showSuccess("Books added to Cart");
        }).fail(function (err){
            showError("Error adding elements to Cart", err);
        });
}

function showResults(book){
    console.log(book);
    title.html(book.title);
    price.html(euro+book.price);
    image.css('background-image', 'url(' + book.image + ')');
    abstract.html(book.abstract);
    statusView.html(book.status);
    addLinks(book.authors,AUTHOR_PAGE,[{key:'authorId',value:'authorId'}], 'name',authorsList);
    addLinks(book.genres,BOOKS_PAGE,[{key:'genreId',value:'genreId'}], 'name',genresList);
    addLinks(book.themes,BOOKS_PAGE,[{key:'themeId',value:'themeId'}], 'name',themesList);
    var src, el;
    for (var b of  book.similarBooks.slice(0, 4)){
        src = similarBookHTML.format(BOOK_PAGE+'?bookId='+b.bookId, b.image, b.title); 
        el = $(src);
        similarBooks.append(el);
    }
    for (var r of book.reviews){
        src = rowHTML.format('fas fa-comments', r.description); 
        el = $(src);
        reviewsList.append(el);
    }

    for (var f of book.facts){
        src = rowHTML.format('fas fa-exclamation', f.description); 
        el = $(src);
        factsList.append(el);
    }
    getBookEvents(bookId)
    .done(function (result,a,request) {
        if (result.events.length == 0){
            var message = "<div class='alert alert-warning alert-dismissible fade show'> \
                     {0}.\
                    <button type='button' class='close' data-dismiss='alert'>&times;</button>\
                    </div>"
            message =message.format("No events associated to this book!")
            eventsList.append(message);
        }
        for (var e of result.events){
            src = rowHTML.format('fas fa-exclamation', e.name); 
            el = $(src);
            el.attr("href", EVENT_PAGE+"?eventId=" + e.eventId);
            eventsList.append(el);
        }
    }).fail(function (err){
        showError("Error getting book events",err);
    });

}

function addLinks(elements,page,query_params, textKey, elementList){
    var src, el,link;
    for(var element of elements){
        link = page+'?'
        for (var qp of query_params){
            link += qp.key+'='+ element[qp.value]+'&';
        }
        src = linkHTML.format(link,element[textKey]); 
        el = $(src);
        elementList.append(el);
    }
}

function init(){
    bookId = GetQueryParams("bookId",window.location.href);
    if(bookId === null){
        alert("NoBookID");
        Redirect('/');
    }
    clearMessages();
    getBookById(bookId)
    .done(function (result,a,request) {
        if(result.bookId === undefined){
            showError("Book does not exist");
            Redirect(BOOKS_PAGE);
        }
        book = result;
        showResults(result);
    }).fail(function (err){
        showError("Error getting book details",err);
    });
}