

var containerHTML = "<div class='container'> </div>";
var rowHTML = "<div class='row equal' id='row-{0}'> </div>"
var authorHTML = "<a href='{0}'>{1}</a>";
var productHTML = "<div class='col-md-3 col-sm-6 panel' id='product={0}'> \
                        <div class='product-grid' id='product-grid-{0}'> \
                            <div class='product-image card h-100' id='product-image-{0}'> \
                                <a href='{1}'> \
                                    <img  class='productImage card-img-top img-fluid pic-1' alt='Responsive image'  src='{2}'> \
                                </a> \
                                <ul class='social'> \
                                    <li><a href='{1}'><i class='fa fa-search product-full-view'></i></a></li> \
                                    <li><a class='bookButton restricted' bookId='{0}' href='#'><i class='fa fa-shopping-cart'></i></a></li> \
                                </ul> \
                            </div> \
                            <div class='product-content'> \
                                <h3 class='title'><a href='{1}'>{3}</a></h3> \
                                <div class='product-details' id='product-details-{0}'>   \
                                </div> \
                                <div class='price'> \
                                    {4} Euro \
                                </div> \
                            </div> \
                        </div> \
                    </div>";
var disabledPaginationClass = 'disabled';
var enabledPaginationClass = 'paginationItem';
var inactivePageHTML = "<li class='page-item'><a class='page-link {2}' id ='page_{0}'>{1}</a></li>";
var activePageHTML = "<li class='page-item active'><a class='page-link {2}' id='page_{0}'>{1}</a>";
var previousPageHTML = "<li class='page-item' id ='{0}PageLink'> \
                        <a class='page-link {3}'  aria-label='{0}'>\
                              <span aria-hidden='true' id='page_{1}'>{2}</span> \
                        </a> \
                    </li>";
    
var genres=$("#genreFilter");
var authorName=$("#authorNameFilter");
var title=$("#titleFilter");
var favorite=$("#favorite");
var bestseller=$("#bestseller");
var limit=$("#limitFilter");
var themes=$("#themeFilter");
var productContainer = $("#productsContainer");
var paginationContainer = $("#paginationList");
var colNumber = 4;
var queryElements = ['authorId','genreId','themeId']
let query ;
var bookList;
function imageError(image) {
    image.onerror = "";
    image.src = PLACEHOLDER_IMAGE;
    return true;
}


function sendQuery(offset){
    clearMessages();
    offset = offset || 0;
    query = query || {};
    if (genres.val() ===null || genres.val() ===undefined || genres.val() === "")
        query.genreId=[];
    else{
        
        query.genreId = genres.val().map(e=>parseInt(e));
    }
        
    if (themes.val() ===null || themes.val() ===undefined || themes.val() === "")
        query.themeId=[];
    else
        query.themeId=themes.val().map(e=>parseInt(e));
    console.log(bestseller.prop("checked"))
    if(bestseller.prop("checked") == true){
        query.bestseller = true;
    }
    else{
        query.bestseller = false;
    }
    if(favorite.prop("checked") == true){
        query.favorite = true;
    }
    else{
        query.favorite = false;
    }
    
    query.limit = parseInt(limit.val());
    query.offset = offset;
    query.authorName = authorName.val();
    query.title = title.val();
    console.log(query);
    getBooks(query)
    .done(function (result,a,request) {
        bookList = result.books;
        console.log(bookList);
        showResults(result.books);
        if(result.books.length == 0)
            paginationContainer.hide();
        else
        {
            paginationContainer.show();
            setPagination(result.pages, result.current_page);
        }
    }).fail(function (err){
        showError("Error getting results",err);
    });
}       

function setPagination(pages, current_page){
    paginationContainer.empty();
    var previous_link_id = -1;

    var previous_link_class = disabledPaginationClass;
    var pagination, paginationSrc;
    if (current_page > 1){
        previous_link_id = current_page-1;
        previous_link_class = enabledPaginationClass;
        paginationSrc = previousPageHTML.format('Previous',previous_link_id,'<', previous_link_class); 
        pagination = $(paginationSrc);
        paginationContainer.append(pagination);
    }
    for(var i=0;i<current_page-1;i++){
        paginationSrc = inactivePageHTML.format( i+1, i+1,enabledPaginationClass);
        pagination = $(paginationSrc);
        paginationContainer.append(pagination);
        if (i==1 && current_page > 3){
            paginationSrc = inactivePageHTML.format( -1, "...", disabledPaginationClass);
            pagination = $(paginationSrc);
            paginationContainer.append(pagination);
        }
    }
    paginationSrc = activePageHTML.format(current_page, current_page, enabledPaginationClass);
    pagination = $(paginationSrc);
    paginationContainer.append(pagination);
    var nextLinkId = -1;
    var nextLinkClass = disabledPaginationClass;
    if (current_page < pages){
        nextLinkId = current_page + 1;
        nextLinkClass = enabledPaginationClass;
        paginationSrc = previousPageHTML.format('Next',nextLinkId,'>', nextLinkClass); 
        pagination = $(paginationSrc);
        paginationContainer.append(pagination);
    }
    $("."+enabledPaginationClass).on('click', function(el) {
        
        var page =parseInt(el.target.id.split('_')[1]);
        if ( page >0 && page != current_page){
            sendQuery(page - 1);
        }
    });
}

function showResults(books){
    var count = 0;
    var row, productSrc;
    productContainer.empty();
    if(books.length == 0)
        showError("No books found with the current filter");

    for(var book of books){
        if(count % colNumber == 0){
            var rowSrc = rowHTML.format(count % colNumber) 
            row = $(rowSrc);
            productContainer.append(row);
        }
        count +=1;
        productSrc = productHTML.format(book.bookId, BOOK_PAGE+"?bookId="+book.bookId,
                                    book.image, book.title, book.price);
        row.append(productSrc);
       
    }
    $('.productImage').on('error', function(el) {imageError(el)});
    $('.bookButton').on('click', function(el) {
        bookProduct($(this).attr("bookId"));
    });
    checkLogin();
}

function bookProduct(bookId){
    clearMessages();
    var index = bookList.findIndex(item => item.bookId == bookId);
    if (index >=0){
        console.log("Booking");
        var book = bookList[index];
        var books =[
            {
                bookId:parseInt(bookId), 
                quantity:1,
                value:book.price,
                image:book.image,
                name:book.title
            }
        ];
        addToCartPost(books)
        .done(function (result,a,request) {
            showSuccess("Book added to Cart");
        }).fail(function (err){
            showError("Error adding book to Cart", err);
        });
    }
    
}
function appendOption(selectField,name, value){
    var o = new Option(name, value);
    /// jquerify the DOM object 'o' so we can use the html method
     $(o).html(name);
     selectField.append(o);
}

function init(){
    var filter, l;
    query={};
    
    getGenres()
    .done(function (result,a,request) {
        
        for (var el of result){
            appendOption(genres,el.name, el.genreId);
        }
        getThemes()
            .done(function (result,a,request) {
                
                for (var el of result){
                    appendOption(themes,el.name, el.themeId);
                }
                
                filter= GetQueryParams('genreId',window.location.href);
                if (filter){
                    l = filter.split(',').map(e=> parseInt(e));
                    query.genreId = l;
                    genres.val(l);
                    
                }
                filter= GetQueryParams('themeId',window.location.href);
                if (filter){
                    l = filter.split(',').map(e=> parseInt(e));
                    query.themeId = l;
                    themes.val(l); 
                }
                filter= GetQueryParams('authorName',window.location.href);
                if (filter){
                    
                    query.authorName = decodeURI(filter);
                    authorName.val(decodeURI(filter)); 
                }
                filter= GetQueryParams('authorId',window.location.href);
                if (filter){
                    
                    l = filter.split(',').map(e=> parseInt(e));
                    query.authorId = l;
                }
                filter= GetQueryParams('best',window.location.href);
                if (filter){
                    
                    query.bestseller = true;
                    bestseller.prop( "checked", true );
                }
                filter= GetQueryParams('favorite',window.location.href);
                if (filter){
                    
                    query.favorite = true;
                    favorite.prop( "checked", true );
                }
                themes.selectpicker('refresh');
                genres.selectpicker('refresh');
                sendQuery();
            }).fail(function (err){
                showError("Error loading book Themes",err);
            });
        
    }).fail(function (err){
        showError("Error loading book Genres",err);
    });

    
    
}