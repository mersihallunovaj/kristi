var rowHTML = "<tr>\
                <td class='col-sm-8 col-md-6'>\
                    <div class='media'> \
                     <a class='thumbnail pull-left' href='{0}'> <img class='media-object' src={1} style='width: 72px; height: 72px;'> </a>\
                    <div class='media-body'>\
                        <h4 class='media-heading'><a href='{0}'>{2}</a></h4>\
                    </div>\
                </div></td>\
                <td class='col-sm-1 col-md-1' style='text-align: center'>\
                    <input type='number'  class='form-control quantity' min='1' step='1'  value='{3}'>\
                </td>\
                <td class='col-sm-1 col-md-1 text-center'><strong>{4}</strong></td>\
                <td class='col-sm-1 col-md-1 text-center'><strong>{5}</strong></td>\
                <td class='col-sm-1 col-md-1'>\
                    <button type='button' class='btn btn-danger removeButton'>\
                        <span class='glyphicon glyphicon-remove'></span> Remove\
                    </button></td>\
              </tr>"
rowHTML = "<tr>\
            <td data-th='Book'>\
                <div class='row'>\
                    <div class='col-sm-2 hidden-xs'><a href='{0}'><img src='{1}' style='width: 72px; height: 72px;'  class='img-responsive'/></div>\
                    <div class='col-sm-10'>\
                        <h4 id ='' class='nomargin'><a href='{0}'>{2}</a></h4>\
                    </div>\
            </div>\
            </td>\
            <td data-th='Price'>{4}</td>\
            <td data-th='Quantity'>\
                <input type='number' class='form-control text-center quantity' value='{3}'>\
            </td>\
            <td data-th='Subtotal' class='text-center'>{5}</td>\
            <td class='actions' >\
                <button class='btn btn-danger btn-sm removeButton'><i class='fa fa-trash'></i> Remove</button>\
            </td>\
        </tr>";
var cartTable = $('#cartRows');
var totalView = $('.totalView');
var checkoutButton = $("#checkoutButton");
var euro = '\u20AC ';
var cart;
function showResults(){
    var c = cart || { total:0, books:[]};
    var row, productSrc;
    cartTable.empty();
    if (c.books.length === 0){
        showWarning("No books in Cart");
        checkoutButton.prop('disabled', true);
    } 
    else{
        checkoutButton.prop('disabled', false);
    }
    for(var book of c.books){
        
        productSrc = rowHTML.format(BOOK_PAGE+"?bookId="+book.bookId, book.image,
                                    book.name, book.quantity, euro+ book.value, euro +  book.value * book.quantity);
        cartTable.append(productSrc);
        
    }
    totalView.html(euro + Math.max(c.total,0));
    $('.removeButton').on('click', function(el) {
        var index = this.closest('tr').rowIndex -1;
        removeRow(index);
    });
    /*$("input.quantity").keypress(function (evt) {
        evt.preventDefault();
    });*/
    $('input.quantity').on('focusout', function() {
        var index = this.closest('tr').rowIndex -1;
        var value = parseInt(this.value) ;
        if (isNaN(value) || value < 0){
            this.value = cart.books[index].quantity;
            return
        }
        var quantity = value  - cart.books[index].quantity;
        updateRow(index, quantity);
    });
}

function continueShopping(){
    Redirect(BOOKS_PAGE);
}

function checkout(){
    if (cart.books.length===0)
        return;
    commitCartPost()
    .done(function(res){
        cart = {boooks:[], total:0};
        console.log(cart);
        cartTable.empty();
        totalView.html(euro + 0);
        checkoutButton.prop('disabled', true);
        showSuccess("Booking completed succesfully!");
    })
    .fail(function(err){
        showError("Error Checking out Cart",err);
    })
}

function updateRow(row,quantity){
    clearMessages();
    var bookId = cart.books[row].bookId;
    var data = {
                "update":[
                    {
                        bookId:bookId,
                        quantity:quantity}
                ]
            }
    updateCartPost(data)
    .done(function(res){
        cart = res
        showResults();
    })
    .fail(function(err){
        showError("Error Updating Cart",err);
    })
}

function removeRow(row){
    clearMessages();
    var bookId = cart.books[row].bookId;
    var data = {
                "update":[
                    {bookId:bookId}
                ]
            }
    updateCartPost(data)
    .done(function(res){
        cart = res;
        showResults();
    })
    .fail(function(err){
        showError("Error Updating Cart",err);
    })
}

function init(){
    clearMessages();
    getCart()
    .done(function(result){
        console.log(result);
        cart = result;
        showResults();
    })
    .fail(function(err){
        showError("Error Getting Cart Information",err);
    })
}
