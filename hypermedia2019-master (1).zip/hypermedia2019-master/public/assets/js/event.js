var similarBookHTML = "<a class='product-box' href={0}> \
                        <span class='img'>\
                      <span style='background-image: url(\"{1}\")' class='i first bounding-box'></span> \
                     </span> \
                    <span class='text'>\
                <strong class='similarTitle'>{2}</strong>\
                </div>\
                </span>\
                </a>";
var rowHTML = "<a  class='list-group-item clearfix'>\
                    <span ><i class='{0}'></i></span>\
                    {1}\
                  </a>";
var eventId, event;
var image=$("#big-image");
var authorsList=$("#authorsList");
var similarBooks=$("#collection-list");
var description = $("#description");
var title=$("#title");
var guestsList=$("#guestsList");
var statusView = $("#statusView");
var bookList;



function showResults(event){
    console.log(event);
    title.html(event.name);
    image.css('background-image', 'url(' + event.image + ')');
    statusView.html(event.location);
    authorsList.html(event.date.substring(0,10));
    if (event.description && event.description != null){
        description.html(event.description);
    }
    var src, el;
    for (var b of event.books.slice(0, 4)){
        src = similarBookHTML.format(BOOK_PAGE+'?bookId='+b.bookId, b.image, b.title); 
        el = $(src);
        similarBooks.append(el);
    }
    for (var g of event.guests){
        src = rowHTML.format('fas fa-comments', g.name); 
        el = $(src);
        reviewsList.append(el);
    }
}


function init(){
    eventId = GetQueryParams("eventId",window.location.href);
    if(eventId === null){
        showError("No Event specified");
        Redirect('/');
        return;
    }
    clearMessages();
    getEventById(eventId)
    .done(function (result,a,request) {
         
        if(result.eventId === undefined){
            showError("Event does not exist");
            Redirect(EVENTS_PAGE);
        }
        showResults(result);
    }).fail(function (err){
        showError("Error getting event details",err);
    });
}