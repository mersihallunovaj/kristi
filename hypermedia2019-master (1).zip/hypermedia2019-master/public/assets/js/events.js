
var rowHTML = "<div class='row equal' id='row-{0}'> </div>"
var authorHTML = "<a href='{0}'>{1}</a>";
var productHTML = "<div class='col-md-3 col-sm-6 panel' id='product={0}'> \
                        <div class='product-grid' id='product-grid-{0}'> \
                            <div class='product-image card h-100' id='product-image-{0}'> \
                                <a href='{1}'> \
                                    <img  class='productImage card-img-top img-fluid pic-1' alt='Responsive image'  src='{2}'> \
                                </a> \
                                <ul class='social'> \
                                    <li><a href='{1}'><i class='fa fa-search product-full-view'></i></a></li> \
                                     \
                                </ul> \
                            </div> \
                            <div class='product-content'> \
                                <h3 class='title'><a href='{1}'>{3}</a></h3> \
                                <div class='product-details' id='product-details-{0}'>   \
                                </div> \
                            </div> \
                        </div> \
                    </div>" ;
var eventList;
var eventName=$("#eventNameFilter");
var limit=$("#limitFilter");
var startDate=$("#startDateFilter");
var endDate=$("#endDateFilter");
var productContainer = $("#productsContainer");
var colNumber = 4
var disabledPaginationClass = 'disabled';
var enabledPaginationClass = 'paginationItem';
var paginationContainer = $("#paginationList");

var inactivePageHTML = "<li class='page-item'><a class='page-link {2}' id ='page_{0}'>{1}</a></li>";
var activePageHTML = "<li class='page-item active'><a class='page-link {2}' id='page_{0}'>{1}</a>";
var previousPageHTML = "<li class='page-item' id ='{0}PageLink'> \
                        <a class='page-link {3}'  aria-label='{0}'>\
                              <span aria-hidden='true' id='page_{1}'>{2}</span> \
                        </a> \
                    </li>";

startDate.datepicker({
    uiLibrary: 'bootstrap4'
});
endDate.datepicker({
    uiLibrary: 'bootstrap4'
});

function imageError(image) {
    image.onerror = "";
    image.src = PLACEHOLDER_IMAGE;
    return true;
}

function setPagination(pages, current_page){
    paginationContainer.empty();
    var previous_link_id = -1;

    var previous_link_class = disabledPaginationClass;
    var pagination, paginationSrc;
    if (current_page > 1){
        previous_link_id = current_page-1;
        previous_link_class = enabledPaginationClass;
        paginationSrc = previousPageHTML.format('Previous',previous_link_id,'<', previous_link_class); 
        pagination = $(paginationSrc);
        paginationContainer.append(pagination);
    }
    for(var i=0;i<current_page-1;i++){
        paginationSrc = inactivePageHTML.format( i+1, i+1,enabledPaginationClass);
        pagination = $(paginationSrc);
        paginationContainer.append(pagination);
        if (i==1 && current_page > 3){
            paginationSrc = inactivePageHTML.format( -1, "...", disabledPaginationClass);
            pagination = $(paginationSrc);
            paginationContainer.append(pagination);
        }
    }
    paginationSrc = activePageHTML.format(current_page, current_page, enabledPaginationClass);
    pagination = $(paginationSrc);
    paginationContainer.append(pagination);
    var nextLinkId = -1;
    var nextLinkClass = disabledPaginationClass;
    if (current_page < pages){
        nextLinkId = current_page + 1;
        nextLinkClass = enabledPaginationClass;
        paginationSrc = previousPageHTML.format('Next',nextLinkId,'>', nextLinkClass); 
        pagination = $(paginationSrc);
        paginationContainer.append(pagination);
    }
    $("."+enabledPaginationClass).on('click', function(el) {
        
        var page =parseInt(el.target.id.split('_')[1]);
        if ( page >0 && page != current_page){
            console.log("sending query:" + page);
            sendQuery(page - 1);
        }
    });
}

function sendQuery(offset){
    offset = offset || 0;
    clearMessages();
    var query = {};
    query.limit = parseInt(limit.val());
    if (eventName.val()){
        query.name = eventName.val();
    }
    if(startDate.val()){
        query.startDate = startDate.val();
    }
    if(endDate.val()){
        query.endDate = endDate.val();
    }
    query.offset = offset;
    console.log(query);
    getEvents(query)
    .done(function (result,a,request) {
        eventList = result.events;
        console.log(eventList);
        showResults(eventList);
        if(eventList.length == 0)
            paginationContainer.hide();
        else
        {
            paginationContainer.show();
            setPagination(result.pages, result.current_page);
        }
        console.log(result);
        showResults(result.events);
    }).fail(function (err){
        showError("Error getting Events",err);
    });
}       

function showResults(events){
    var count = 0;
    var row, productSrc;
    productContainer.empty();
    if(events.length == 0)
        showError("No events found with the current filter");
    for(var event of events){
        if(count % colNumber == 0){
            var rowSrc = rowHTML.format(count % colNumber) 
            row = $(rowSrc);
            productContainer.append(row);
        }
        count +=1;
        productSrc = productHTML.format(event.eventId, EVENT_PAGE+"?eventId="+event.eventId,
                event.image, event.name);
        row.append(productSrc);
        $('.productImage').on('error', function(el) {imageError(el)});
    }
}

function appendOption(selectField,name, value){
    var o = new Option(name, value);
    /// jquerify the DOM object 'o' so we can use the html method
     $(o).html(name);
     selectField.append(o);
}

function init(){
    
    var filter= GetQueryParams('upcoming',window.location.href);
    if (filter){
        startDate.val(new Date().toDateInputValue());
        endDate.val(new Date().addDays(31).toDateInputValue());
        console.log("Not implemented");
    }
    sendQuery();
}