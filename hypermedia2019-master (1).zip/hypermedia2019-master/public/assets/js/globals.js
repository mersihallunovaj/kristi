let SERVER = "/v1";
let PLACEHOLDER_IMAGE = "/assets/img/placeholder.png";
let AUTHOR_PAGE = '/pages/author';
let BOOK_PAGE = '/pages/book';
let LOGIN_PAGE = '/pages/log_in';
let REGISTER_PAGE = '/pages/register';
let EVENT_PAGE = '/pages/event';
let BOOKS_PAGE = '/pages/books';
let AUTHORS_PAGE = '/pages/authors';
let EVENTS_PAGE = '/pages/events';
let linkHTML = "<a href='{0}'>{1}  </a>";
let successHTML = "<div class='alert alert-success alert-dismissible fade show'>\
                    <strong>Success!</strong> {0}\
                <button type='button' class='close' data-dismiss='alert'>&times;</button>\
                </div>";
let errorHTML = "<div class='alert alert-danger alert-dismissible fade show'> \
                <strong>Error!</strong> {0}.\
                <button type='button' class='close' data-dismiss='alert'>&times;</button>\
                </div>"
let warningHTML = "<div class='alert alert-warning alert-dismissible fade show'> \
                <strong>Warning!</strong> {0}.\
                <button type='button' class='close' data-dismiss='alert'>&times;</button>\
                </div>"

Date.prototype.toDateInputValue = (function() {
                    var local = new Date(this);
                    local.setMinutes(this.getMinutes() - this.getTimezoneOffset());
                    return local.toJSON().slice(0,10);
                });
Date.prototype.addDays = function(days) {
                    var date = new Date(this.valueOf());
                    date.setDate(date.getDate() + days);
                    return date;
                }
String.prototype.format = function() {
    var formatted = this;
    for (var i = 0; i < arguments.length; i++) {
        var regexp = new RegExp('\\{'+i+'\\}', 'gi');
        formatted = formatted.replace(regexp, arguments[i]);
    }
    return formatted;
};

function logoutPost(){
    $.ajax({
        url: SERVER + "/user/logout",
        type: "DELETE",
    }).done(function(response){
        Redirect('/');
    }).fail(function(err){
        showError("Error logging out");
    });

}

function Redirect(link){
    window.location.href = link;
}

function GetQueryParams( name, url ) {
    if (!url) url = location.href;
    name = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
    var regexS = "[\\?&]"+name+"=([^&#]*)";
    var regex = new RegExp( regexS );
    var results = regex.exec( url );
    return results == null ? null : results[1];
}

function addLinks(elements,page,query_params, textKey, elementList){
    var src, el,link;
    for(var element of elements){
        link = page+'?'
        for (var qp of query_params){
            link += qp.key+'='+ element[qp.value]+'&';
        }
        src = linkHTML.format(link,element[textKey]); 
        el = $(src);
        elementList.append(el);
    }
}

function showError(def,err){
    var errorMessage =  def || "Unexpected Error";
    if(err !== undefined){
        errorMessage = err.responseJSON.error || err.responseJSON.detail || errorMessage;
    }
    var src = errorHTML.format(errorMessage); 
    var el = $(src);
    $(".messageContainer").empty();
    $(".messageContainer").append(el);
    console.log(errorMessage);
    
}

function clearMessages(){
    $(".messageContainer").empty();
}
function showWarning(def,err){
    var errorMessage =  def || "Unexpected Error";
    if(err){
        errorMessage = err.responseJSON.error || err.responseJSON.detail || errorMessage;
    }
    var src = warningHTML.format(errorMessage); 
    var el = $(src);
    $(".messageContainer").empty();
    $(".messageContainer").append(el);
    console.log(errorMessage);
    
}


function showSuccess(message){
    var successMessage = message || "The operation was successful";
    var src = successHTML.format(successMessage); 
    var el = $(src);
    $(".messageContainer").empty();
    $(".messageContainer").append(el);
    console.log(successMessage);
    
}
