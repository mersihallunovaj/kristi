$(function(){
    var includes = $('[data-include]');
    jQuery.each(includes, function(){
      var file = $(this).data('include');
      $(this).load(file, function(responseTxt, statusTxt, xhr){
        checkLogin();
      })
    });
  });

  function getcookie(cookiename, decode) {
    var cookiestring=""+document.cookie;
    var index1=cookiestring.indexOf(cookiename);
    
    if (index1==-1 || cookiename=="") return "{}"; 
    var index2=cookiestring.indexOf(';',index1);
    if (index2==-1) index2=cookiestring.length; 
        if (decode)
          return atob(cookiestring.substring(index1+cookiename.length+1,index2));
        return cookiestring.substring(index1+cookiename.length+1,index2);
  }
  function checkLogin(){
    var session = JSON.parse(getcookie("session",true));
  var navbar = $("#navbarResponsive");
  var navbarList = $("#navbarList");
  if (session.userId){
    $(".unrestricted").remove();
    return true;
  }
  else{
    $(".restricted").remove();
    return false;
  }
  
  }
  //checkLogin();
  

  function logout(){
    console.log("logging out");
  }


  $('.tabLabel').on('click', function() {
    var tab = $(this);
    var data = tab.attr('ref');
    var ref = $('.slidePanel[data='+data+']');
    var activeTab = $('.tabLabel.active');
    var activePanel = $('.slidePanel.active');
    activeTab.removeClass('active');
    activePanel.removeClass('active');
    tab.addClass('active');
    ref.addClass('active');
  });
  