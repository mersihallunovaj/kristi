//let $ = require('jquery');
let components = [
                    "log_in",
                    "about",
                    "author",
                    "book"
                    ]


function load_login_component(){
    console.log("Loading");
    $.ajax({
        url: "http://localhost:8080/pages/log_in",
        type: "GET",
        headers: {
            "Access-Control-Allow-Origin": "*"
        },
        success : function (result) {
        console.log(result);
        $("#content_root").html(result);
        }, 
        error : function (xhr,status,err) {
            console.log("error");
            var textStatus = "";
            if(err.responseJSON)
                textStatus=JSON.stringify(err.responseJSON.error);
            else if(err.responseText)
                textStatus=err.responseText;
            else if (err.message)
                textStatus=err.message;
            else
                textStatus="Something Went Wrong in the request";    
            $("#content_root").html(textStatus);
    }});
    $(".navbar-collapse").collapse("hide");
}
