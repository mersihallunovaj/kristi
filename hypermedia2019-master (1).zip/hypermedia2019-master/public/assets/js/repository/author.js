function getAuthors(query){
    return $.ajax({
        url: SERVER + "/authors",
        type: "GET",
        data: query
    })
   
}

function getAuthorById(authorId){
    return $.ajax({
        url: SERVER + "/authors/"+authorId,
        type: "GET",
        
    })
}
