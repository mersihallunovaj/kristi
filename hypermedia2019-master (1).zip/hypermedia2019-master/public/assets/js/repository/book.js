function getBooks(query){
        return $.ajax({
            url: SERVER + "/books",
            type: "POST",
            contentType: 'application/json',
            data: JSON.stringify(query), 
            dataType: "json"
        })
       
}

function getBookById(bookId){
    return $.ajax({
        url: SERVER + "/books/"+bookId,
        type: "GET",
        
    })
   
}

function getBookEvents(bookId){
    return $.ajax({
        url: SERVER + "/books/"+bookId+"/events",
        type: "GET",
    })
   
}

