function addToCartPost(books){
    var query = {
            books:books
    };
    console.log(query);

    return $.ajax({
        url: SERVER + "/cart/add",
        type: "POST",
        contentType: 'application/json',
        data: JSON.stringify(query), 
        dataType: "json"
    })
   
}

function getCart(){
    return $.ajax({
        url: SERVER + "/cart",
        type: "GET",
    })
   
}

function updateCartPost(data){
    
    console.log(data);
    return $.ajax({
        url: SERVER + "/cart/update",
        type: "POST",
        contentType: 'application/json',
        data: JSON.stringify(data), 
        dataType: "json"
    })
   
}

function commitCartPost(){
    
    return $.ajax({
        url: SERVER + "/cart/commit",
        type: "POST",
    })
   
}