function getEvents(query){
    return $.ajax({
        url: SERVER + "/events",
        type: "GET",
        data: query
    })
   
}

function getEventById(eventId){
    return $.ajax({
        url: SERVER + "/events/"+eventId,
        type: "GET",
        
    })
}

