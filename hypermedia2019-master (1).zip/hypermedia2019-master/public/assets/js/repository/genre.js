var server = 'http://localhost:8080/v1'
function getGenres(){
        return $.ajax({
            url: SERVER + "/genres",
            type: "GET",
            processData: false,
        })
       
}