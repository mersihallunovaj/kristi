function getThemes(){
        return $.ajax({
            url: SERVER + "/themes",
            type: "GET",
            processData: false,
        })
       
}