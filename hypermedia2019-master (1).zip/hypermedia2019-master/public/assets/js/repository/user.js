function registerPost(user){
    return $.ajax({
        url: SERVER + "/user/register",
        type: "POST",
        contentType: 'application/json',
        data: JSON.stringify(user), 
        dataType: "json"
    })
   
}

function loginPost(username, password){
    var user = {
        username:username,
        password:password
    };
    console.log(user);
    return $.ajax({
        url: SERVER + "/user/login",
        type: "POST",
        contentType: 'application/json',
        data: JSON.stringify(user), 
        dataType: "json"
    })

}



