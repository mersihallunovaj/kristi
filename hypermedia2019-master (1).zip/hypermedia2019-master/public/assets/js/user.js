function validateAndLogin(){
    var form = $('#loginForm')[0];
    if(! form.checkValidity()){
        console.log('invalid');
        $('<input type="submit">').hide().appendTo(form).click().remove();
    }
    else{
        var username, password;
        username = $('#username').val();
        password = $('#password').val()
        loginPost(username,password)
        .done(function (result,a,request) {
            console.log(result);
            var filter= GetQueryParams('bookId',window.location.href);  
            if (filter){
               Redirect(BOOK_PAGE+"?bookId="+filter);
            }
            else
                Redirect(BOOKS_PAGE);
        }).fail(function (err){
            showError("Error while logging in",err);
        });
    }
}

function validateAndRegister(){
    var form = $('#registerForm')[0];
    
    if(! form.checkValidity()){
        $('<input type="submit">').hide().appendTo(form).click().remove();
    }
    else{
        var email, password,name,address;
        
        email = $('#email').val();
        password = $('#password').val();
        name = $('#name').val();
        address = $('#address').val();
        var data = {
            name:name,
            email:email,
            password:password,
            address:address
        }
        registerPost(data)
        .done(function (result,a,request) {
            var filter= GetQueryParams('bookId',window.location.href);  
            if (filter){
               Redirect(BOOK_PAGE+"?bookId="+filter);
            }
            else
                Redirect(BOOKS_PAGE);
        }).fail(function (err){
            showError("Error while Registering",err);
        });
    }
}

function goLogin(){
    var filter= GetQueryParams('bookId',window.location.href);
    var url = LOGIN_PAGE;
    if (filter){
        url += "?bookId="+filter;
    }
    Redirect(url);
}

function goRegister(){
    var filter= GetQueryParams('bookId',window.location.href);
    var url = REGISTER_PAGE;
    if (filter){
        url += "?bookId="+filter;
    }
    Redirect(url);
}